package baiTapTuGiaiChuong1;
import java.util.*;
public class nguyenvinhkhang_bai9_tugiaiC1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int b;
	   String a;
       Scanner vk=new Scanner(System.in);
	   System.out.println("Nhập chuỗi: ");
	   a=vk.nextLine();
	   b=Integer.parseInt(a);
	   System.out.println("đổi chuỗi số nguyên sang số nguyên: "+a);
	   
	   
	}

}
